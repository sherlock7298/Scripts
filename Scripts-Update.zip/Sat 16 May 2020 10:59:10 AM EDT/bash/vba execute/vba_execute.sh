#!/bin/bash
clear
echo '----------------------------------------------------------------------------------------------------'
echo 'VBA CODER INYECTOR'
echo '----------------------------------------------------------------------------------------------------'
echo 'Select the file with the command:'
echo '----------------------------------------------------------------------------------------------------'
ls -f
for fileget in ./*.cmd
do
	if [[ -f "${fileget}" ]]; then
	stat='true';
	break
	fi
done
if [[ $stat != 'true' ]]; then
	for fileget in ./*.bat
	do
		if [[ -f "${fileget}" ]]; then
		stat='true';
		break
		fi
	done
fi
if [[ $stat='true' ]]; then
	echo '----------------------------------------------------------------------------------------------------'
	read -p '->' filename
	echo '----------------------------------------------------------------------------------------------------'
else
	echo 'No files to work exist!'
	echo '----------------------------------------------------------------------------------------------------'
	exit
fi
if [[ -f $filename ]]; then
	#read filename
	command=''
	while IFS= read -r filename_read_line
	do
		command="$command && ${filename_read_line//'"'/'¬¬'}"
	done < <(cat $filename)
	#create vbs script
	echo "set objShell = WScript.CreateObject(¬¬Wscript.Shell¬¬)">>run_$filename
	echo "runCommand = ¬¬cmd /k echo. $command¬¬">>run_$filename
	echo "objShell.Run runCommand">>run_$filename
	while IFS= read -r vba_read_line
	do
		line_print=${vba_read_line//'¬¬'/'"'}
		echo $line_print>>run_$filename.vbs
	done < <(cat run_$filename)
	rm run_$filename
	echo 'Finished!'
else
	echo 'The file not exist!'
fi
