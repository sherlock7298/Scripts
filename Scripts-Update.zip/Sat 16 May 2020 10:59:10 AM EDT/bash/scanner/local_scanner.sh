#!/bin/bash
clear
#var
array_device_ip=()
array_device_mac=()
array_device_description=()
#sources
echo 'Veryfing dependences!'
array_dependences=('arp-scan' 'nmap')
for j in "${array_dependences[@]}"
do
	if [[ $(which $j) != '' ]]; then
		echo "[+] $j is installed!"
	else
		echo "[-] no such $j!"
		echo "[*] installing $j!"
		apt-get install $j
		echo "[+] $j has been installed!"
	fi
done
#files
rpt_index='rpt-ip'
connections_capture='reg_connections.network'
if [[ -f $connections_capture ]]; then
	rm $connections_capture
fi
sleep 3
clear
gateway_ip=$(netstat -rn|grep 'UG[ \t]'|awk '{print $2}')
arp-scan $gateway_ip"/24">>$connections_capture
cat $connections_capture
while IFS= read -r reg_connections
do
	if [[ $reg_connections != *'Interface'* && $reg_connections != *'arp-scan'* && $reg_connections != *'packets'* && $reg_connections != '' ]]; then
		device_ip=$(echo $reg_connections|awk '{print $1}')
		device_mac=$(echo $reg_connections|awk '{print $2}')
		device_description=${reg_connections/$device_ip/''}
		device_description=${device_description/$device_mac/''}
		#device_description=$(echo $reg_connections|awk '{print $3}')
		array_device_ip+=($device_ip)
		array_device_mac+=($device_mac)
		array_device_description+=($device_description)
	fi
done < <(cat reg_connections.network)
clear
total_devices=0
set_folder_save=$(date)
mkdir "$set_folder_save"
echo 'Running scan!'
for i in "${array_device_ip[@]}"
do
	echo '----------------------------------------------------------------'
	let total_devices=$total_devices+1
	echo "Checking ports on: $i"
#Operating system
	echo 'Operating system...'
	echo 'Operating system...'>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -O $i>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -v -A $i>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'
	while IFS= read -r ip_lines
	do
		if [[ $ip_lines == 'Aggressive OS guesses:'* || $ip_lines == 'OS CPE:'* ]]; then
			echo $ip_lines
		fi
	done < <(cat "$set_folder_save/$i.$rpt_index")
	echo '----------------------------------------------------------------'
#Service scanning
	echo 'Service scanning...'
	echo 'Service scanning...'>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -sV $i>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -sA $i>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
#Firewall bypass
	echo 'Firewall bypass...'
	echo 'Firewall bypass...'>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -PN $i>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -PS $i>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -PA $i>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
#Broke firewall
	echo 'Broke firewall...'
	echo 'Broke firewall...'>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -sN $i>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -sF $i>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -sX $i>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
#Call from gateway
	echo 'Call from gateway...'
	echo 'Call from gateway...'>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
	nmap -n $i -D $gateway_ip>>"$set_folder_save/$i.$rpt_index"
	echo '----------------------------------------------------------------'>>"$set_folder_save/$i.$rpt_index"
#Ports
	echo 'Print ports info:'
	echo '----------------------------------------------------------------'
	while IFS= read -r ip_lines
	do
		if [[ $ip_lines == *'open port'* ]]; then
			echo $ip_lines
		fi
	done < <(cat "$set_folder_save/$i.$rpt_index")
	echo '----------------------------------------------------------------'
done
echo "Total devices: $total_devices"
