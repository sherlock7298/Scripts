#!/bin/bash
apt update
apt upgrade -y
apt -y install lsb-release apt-transport-https ca-certificates
wget -0 /etc/apt/trusted.gpg.d/php.gpg https://packages.sury.org/php/apt.gpg
echo "deb https://packages.sury.org/php/ buster main" | sudo tee /etc/apt/sources.list.d/php.list
apt update
apt -y install php7.4
php -v
apt-get install php7.4-{cli,json,imap,bcmath,bz2,intl,gd,mbstring,mysql,zip}

